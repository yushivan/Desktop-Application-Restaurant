/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kasir;

/**
 *
 * @author yushivan
 */
public class fungsi1 extends menu_pesanan implements fungsihitung{
    
    @Override
    public int total(int harga2,int jumlah3){
        int totalperpesanan = harga2 * jumlah3;
        return totalperpesanan;
    }
    @Override
    public int pajak(int total){
        int total2 = total;
        int pajak = total2 * 10/100;
        return pajak;
    }
    @Override
    public int kembalian(int total,int pajak,int bayar){
        int kembalian = bayar - total - pajak;
        return kembalian;
    }
}
